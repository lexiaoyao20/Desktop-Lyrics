//
//  VOutTextRender.h
//  PlayerView
//
//  Created by ws ws on 5/20/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VOutTextRender : NSObject {
    NSTextContainer * _textContainer;
    NSTextStorage   * _textStorage;
    NSLayoutManager * _layoutManager;
    
    NSMutableDictionary * _textAttributeds;
    
    id _delegate;
    
    NSThread * _renderThread;
}

@property(readwrite, retain) id delegate;

// 返回taskID，当前无用
- (NSBitmapImageRep *)render:(NSString *)context;

- (void)setValue:(id)value forKey:(NSString *)key;

@end

@interface NSObject (VOutTextRenderDelegate)

// taskID当前无用
- (void)renderDidFinish:(NSBitmapImageRep *)img forContext:(NSString *)context taskID:(NSInteger)taskID;

@end
