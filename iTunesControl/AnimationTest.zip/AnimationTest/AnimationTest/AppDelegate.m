//
//  AppDelegate.m
//  AnimationTest
//
//  Created by bo su on 13-7-10.
//  Copyright (c) 2013年 wondershare. All rights reserved.
//

#import "AppDelegate.h"
#import "NSColor+CGColor.h"
#import "NSImage+Additions.h"
#import "VOutTextRender.h"

#define DefaultFontName @"Verdana"
#define DefaultFontSize 32

@implementation AppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
//    [view setWantsLayer:YES];
//    textLayer = [[CATextLayer layer] retain];
//    
//    textLayer.font = DefaultFontName;
//    textLayer.fontSize = DefaultFontSize;
//    textLayer.backgroundColor = [[NSColor clearColor] CGColor];
//    textLayer.shadowColor = [[NSColor clearColor] CGColor];
//    textLayer.shadowOffset = CGSizeMake(1, 1);
//    textLayer.shadowOpacity = 0.9;
//    textLayer.shadowRadius = 10;
//    textLayer.string = @"AAA";
//    textLayer.alignmentMode = kCAAlignmentCenter;
//    textLayer.foregroundColor = [[NSColor orangeColor] CGColor];
//    
//    [view.layer addSublayer:textLayer];
//    textLayer.frame = view.layer.frame;
    
//    textRender = [[VOutTextRender alloc] init];
//    
//    NSBitmapImageRep *imageRep = [textRender render:@"aagg kkk xxx fafs"];
//    NSImage *image = [[[NSImage alloc] init] autorelease];
//    [image addRepresentation:imageRep];
//    [imageView setImage:image];
    
    
    
//    CIFilter	*transitionFilter = [CIFilter filterWithName:@"CIFlashTransition"]; 
//    [transitionFilter setDefaults];
//    
//    CATransition *newTransition = [CATransition animation];
//    if (transitionFilter)
//	{
//        // we want to build a CIFilter-based CATransition.
//		// When an CATransition's "filter" property is set, the CATransition's "type" and "subtype" properties are ignored,
//		// so we don't need to bother setting them.
//        [newTransition setFilter:transitionFilter];
//    }
//    [newTransition setDuration:2.0];
//    [imageView setAnimations:[NSDictionary dictionaryWithObject:newTransition forKey:@"subviews"]];
//    
//    frogImage = [NSImage imageNamed:@"Frog"];
//    roseImage = [NSImage imageNamed:@"Rose"];
//    
//    [self transitionToImage:frogImage];
}

- (void)initTransition {
//    theTransition = [CIFilter filterWithName:@"CIFlashTransition"];
//    [theTransition setDefaults];
}

- (IBAction)playText:(id)sender {
    NSString *hello = @"Hello world";
    [imageView setLyricString:hello];
}


- (CGImageRef)CGImageFormLayer:(CALayer *)layer {
    CGSize imageSize = layer.frame.size;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName(kCGColorSpaceGenericRGB);
    CGContextRef theContext = CGBitmapContextCreate(NULL/*data - pass NULL to let CG allocate the memory*/, 
                                                    imageSize.width,  
                                                    imageSize.height, 
                                                    8 /*bitsPerComponent*/, 
                                                    0 /*bytesPerRow - CG will calculate it for you if it's allocating the data.  This might get padded out a bit for better alignment*/, 
                                                    colorSpace, 
                                                    kCGBitmapByteOrder32Host|kCGImageAlphaPremultipliedFirst);
    
    [layer renderInContext:theContext];
    
    CGImageRef cgImage = (CGBitmapContextCreateImage(theContext));
    CGContextRelease(theContext);
    
    return (CGImageRef)[(id)cgImage autorelease];
}

@end
