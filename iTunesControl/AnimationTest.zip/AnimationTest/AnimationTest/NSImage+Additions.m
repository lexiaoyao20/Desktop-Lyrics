//
//  NSImage+Additions.m
//  Wondershare Player
//
//  Created by ws ws on 3/29/13.
//  Copyright (c) 2013 Wondershare. All rights reserved.
//

#import "NSImage+Additions.h"

@implementation NSImage (SwatchColor)

+(NSImage *)swatchWithColor:(NSColor *)color size:(NSSize)size
{
    NSImage *image = [[[NSImage alloc] initWithSize:size] autorelease];
    [image lockFocus];
    [color drawSwatchInRect:NSMakeRect(0, 0, size.width, size.height)];
    [image unlockFocus];
    return image;    
}

- (CGImageRef)cgImage
{
	NSData* data = [self TIFFRepresentation];
	return CreateCGImageFromData(data);
}

@end

CGImageRef CreateCGImageFromData(NSData* data)
{
    CGImageRef        imageRef = NULL;
    CGImageSourceRef  sourceRef;
    
    sourceRef = CGImageSourceCreateWithData((CFDataRef)data, NULL);
    if(sourceRef) {
        imageRef = CGImageSourceCreateImageAtIndex(sourceRef, 0, NULL);
        CFRelease(sourceRef);
    }
    
    return imageRef;
}