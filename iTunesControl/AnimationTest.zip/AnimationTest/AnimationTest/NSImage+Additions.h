//
//  NSImage+Additions.h
//  Wondershare Player
//
//  Created by ws ws on 3/29/13.
//  Copyright (c) 2013 Wondershare. All rights reserved.
//

#import <Foundation/Foundation.h>

CGImageRef CreateCGImageFromData(NSData* data);

@interface NSImage (SwatchColor)

+(NSImage *)swatchWithColor:(NSColor *)color size:(NSSize)size;

- (CGImageRef)cgImage;


@end
