//
//  VOutTextRender.m
//  PlayerView
//
//  Created by ws ws on 5/20/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "VOutTextRender.h"

@implementation VOutTextRender

@synthesize delegate = _delegate;

- (void)threadMain
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    NSRunLoop* myRunLoop = [NSRunLoop currentRunLoop];
    
    NSPort * port = [NSPort port];
    [[NSRunLoop currentRunLoop] addPort:port forMode:NSDefaultRunLoopMode];
    // The application uses garbage collection, so no autorelease pool is needed.
    
    //    NSLog(@"threadMain");
    do{
        NSAutoreleasePool * tpool = [[NSAutoreleasePool alloc] init];
        [myRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
        //        NSLog(@"threadMain ......");
        [tpool drain], tpool = nil;
        
    }while (1);
    [pool drain], pool = nil;
}

- (id)init {
    self = [super init];
    
    if (self) {
        _textStorage = nil;
        _textContainer = [[NSTextContainer alloc] initWithContainerSize:NSMakeSize(NSIntegerMax, NSIntegerMax)];
        _layoutManager = [[NSLayoutManager alloc] init];
        
        [_layoutManager setHyphenationFactor:0.0] ;
        [_layoutManager setUsesScreenFonts:NO];
        
        [_layoutManager addTextContainer:_textContainer];
        
        [self initDefaultAttributes];
    }
    return self;
}

- (void)dealloc {
    [_delegate release];
    _delegate = nil;
    
    [_textStorage release];
    _textStorage = nil;
    
    [_textContainer release];
    _textContainer = nil;
    
    [_layoutManager release];
    _layoutManager = nil;
    
    [_textAttributeds release];
    _textAttributeds = nil;
    
    [super dealloc];
}

- (void)initDefaultAttributes {
    if (_textAttributeds) {
        [_textAttributeds release];
        _textAttributeds = nil;
    }
    
    _textAttributeds = [[NSMutableDictionary alloc] init];
        
    [_textAttributeds setValue:[NSFont fontWithName:@"Lucida Grande" size:17] forKey:NSFontAttributeName];
    [_textAttributeds setValue:[NSColor greenColor] forKey:NSForegroundColorAttributeName];
    [_textAttributeds setValue:[NSNumber numberWithFloat:-3] forKey:NSStrokeWidthAttributeName];//轮廓宽度
//    [_textAttributeds setValue:[NSColor orangeColor] forKey:NSStrokeColorAttributeName];//轮廓颜色
    
    NSMutableParagraphStyle* paraStyle = [[NSMutableParagraphStyle alloc] init];
	[paraStyle setAlignment:NSCenterTextAlignment];
	[paraStyle setLineBreakMode:NSLineBreakByWordWrapping];
	[_textAttributeds setValue:paraStyle forKey:NSParagraphStyleAttributeName];
}

- (void)setValue:(id)value forKey:(NSString *)key {
    if (value && key) {
        [_textAttributeds setValue:value forKey:key];
    }
}

- (void)updateTextContent:(NSString *)aString {
    
    if (!_textAttributeds) {
        [self initDefaultAttributes];
    }
    
    if (_textStorage) {
        [_textStorage release]; _textStorage = nil;
    }

    _textStorage = [[NSTextStorage alloc] initWithString:aString attributes:_textAttributeds];
}

- (NSSize)caculateRepSize {
    
    // force text layout
    [_layoutManager glyphRangeForTextContainer:_textContainer];
    
	return NSIntegralRect([_layoutManager usedRectForTextContainer:_textContainer]).size;
}

- (NSBitmapImageRep *)createRep:(NSSize)repSize {
    
    NSBitmapImageRep * bitmapRep = nil;

    if (repSize.width > 0 && repSize.height > 0) {
        
        int pixelsWide = repSize.width, pixelsHigh = repSize.height; 
        CGContextRef ctx = NULL;
        
        bitmapRep = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes: nil  // Nil pointer makes the kit allocate the pixel buffer for us.
         pixelsWide: pixelsWide  // The compiler will convert these to integers, but I just wanted to  make it quite explicit
         pixelsHigh: pixelsHigh //
         bitsPerSample: 8
         samplesPerPixel: 4  // Four samples, that is: RGBA
         hasAlpha: YES
         isPlanar: NO  // The math can be simpler with planar images, but performance suffers..
         colorSpaceName: NSCalibratedRGBColorSpace  // A calibrated color space gets us ColorSync for free.
         bytesPerRow: pixelsWide * 4      // Passing zero means "you figure it out."
         bitsPerPixel: 32];  // This must agree with bitsPerSample and samplesPerPixel.;
        
        if (bitmapRep) {
            ctx = CGBitmapContextCreate([bitmapRep bitmapData], [bitmapRep size].width, [bitmapRep size].height, [bitmapRep bitsPerSample], [bitmapRep bytesPerRow], [[bitmapRep colorSpace] CGColorSpace], kCGImageAlphaPremultipliedLast);
        }
        
        if (ctx) {
            
            NSGraphicsContext *nsGraphicsContext;
            nsGraphicsContext = [NSGraphicsContext graphicsContextWithGraphicsPort:ctx
                                                                           flipped:YES];
            [NSGraphicsContext saveGraphicsState];
            [NSGraphicsContext setCurrentContext:nsGraphicsContext];
            
            [nsGraphicsContext setShouldAntialias:YES];
            
            NSRange glyphRange = [_layoutManager
                                  glyphRangeForTextContainer:_textContainer];
            
            NSAffineTransform *transform = [NSAffineTransform transform];
            [transform translateXBy:0 yBy:pixelsHigh];
            [transform scaleXBy:1.0 yBy:-1.0];
            [transform concat];
            
            [_layoutManager drawGlyphsForGlyphRange:glyphRange atPoint:NSZeroPoint];
                        
            [NSGraphicsContext restoreGraphicsState];            
        }
        
        if (ctx) {
            CGContextRelease(ctx); ctx = nil;
        }
    }
    
    return bitmapRep;
}

- (NSBitmapImageRep *)render:(NSString *)context {
    
//    @synchronized (@"VOutTextRender_BeginTask") {
//        
//        if (!_renderThread) {
//            _renderThread = [[NSThread alloc] initWithTarget:self selector:@selector(threadMain) object:nil];
//            [_renderThread start];
//        }
//        
//        if (_renderThread) {
//            [self performSelector:@selector(_render:) onThread:_renderThread withObject:context waitUntilDone:NO];
//        } else {
//            [self _render:context];
//        }
//    }
//    return -1;
    return [self _render:context];
}

- (NSBitmapImageRep *)_render:(NSString *)context {
//    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    NSBitmapImageRep * image = nil;
    NSSize imageSize = NSZeroSize;
    
    @synchronized (@"VOutTextRender_Rendering") {
        
        [self updateTextContent:context];
        
        [_textStorage addLayoutManager:_layoutManager];
        
        imageSize = [self caculateRepSize];
        
        image = [self createRep:imageSize];
    }
    
//    if (_delegate && [_delegate respondsToSelector:@selector(renderDidFinish:forContext:taskID:)]) {
//        [_delegate renderDidFinish:image forContext:context taskID:-1];
//    }
    
//    [image release]; image = nil;
//    
//    [pool drain]; pool = nil;
    
    return [image autorelease];  
}
@end
