//
//  LyricView.m
//  AnimationTest
//
//  Created by bo su on 13-7-11.
//  Copyright (c) 2013年 wondershare. All rights reserved.
//

#import "LyricView.h"
#import "VOutTextRender.h"

@implementation LyricView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        textRender = [[VOutTextRender alloc] init];
    }
    
    return self;
}

- (void)drawRect:(NSRect)rectangle
{
    float   t;
    CGRect  cg = CGRectMake(NSMinX(rectangle), NSMinY(rectangle),
                            NSWidth(rectangle), NSHeight(rectangle));
    
//    t   = 0.4*([NSDate timeIntervalSinceReferenceDate] - base);
    t = base / [sourceImage extent].size.width;
    base++;
  //  NSLog(@"time:%f",t);
    if(context == nil)
    {
        context = [CIContext contextWithCGContext:
                   [[NSGraphicsContext currentContext] graphicsPort]
                                          options: nil];
        [context retain];
    }
    if(transition == nil)
        [self setupTransition];
    [context drawImage: [self imageForTransition: t]
               atPoint: cg.origin
              fromRect: cg];
}

- (void)awakeFromNib {
    
    thumbnailWidth  = 340.0;
    thumbnailHeight = 240.0;
    
    
}

- (void)setupTransition
{
    if (transition) {
        [transition release];
        transition = nil;
    }
    CIVector  *extent;
    float      w,h;
    
    w      = thumbnailWidth;
    h      = thumbnailHeight;
    
    extent = [CIVector vectorWithX: 0  Y: 0  Z: w  W: h];
    
    transition  = [[CIFilter filterWithName: @"CISwipeTransition"] retain];
    [transition setDefaults];
    NSArray		*filterKeys = [transition inputKeys];
    NSDictionary	*filterAttributes = [transition attributes];
    if(filterKeys)
    {
        NSEnumerator	*enumerator = [filterKeys objectEnumerator];
        NSString		*currentKey;
        NSDictionary	*currentInputAttributes;
        
        while(currentKey = [enumerator nextObject]) 
        {
            if([currentKey compare:@"inputExtent"] == NSOrderedSame)		    // set the rendering extent to the size of the thumbnail
                [transition setValue:extent forKey:currentKey];
            else if ([currentKey compare:@"inputWidth"] == NSOrderedSame) {
                [transition setValue:[NSNumber numberWithInt:1] forKey:currentKey];
            }
            else {
                currentInputAttributes = [filterAttributes objectForKey:currentKey];
                
                NSString		    *classType = [currentInputAttributes objectForKey:kCIAttributeClass];
                
                if([classType compare:@"CIImage"] == NSOrderedSame)
                {
                    if([currentKey compare:@"inputShadingImage"] == NSOrderedSame){	// if there is a shading image, use our shading image 
                        
                    }
                    else if ([currentKey compare:@"inputBacksideImage"] == NSOrderedSame){	// this is for the page curl transition
                    }
                    else 
                        [transition setValue:sourceImage forKey:currentKey];
                }
            }
        }
    }
}

- (CIImage *)imageForTransition: (float)t
{
    CIFilter  *crop;
    
//    if(fmodf(t, 2.0) < 1.0f)
//    {
        [transition setValue: sourceImage  forKey: @"inputImage"];
        [transition setValue: targetImage  forKey: @"inputTargetImage"];
//    }
//    else
//    {
//        [transition setValue: targetImage  forKey: @"inputImage"];
//        [transition setValue: sourceImage  forKey: @"inputTargetImage"];
//    }
    
    [transition setValue: [NSNumber numberWithFloat:
                           0.5*(1-cos(fmodf(t, 1.0f) * M_PI))]
                  forKey: @"inputTime"];
    
    crop = [CIFilter filterWithName: @"CICrop"
                      keysAndValues: @"inputImage",
            [transition valueForKey: @"outputImage"],
            @"inputRectangle", [CIVector vectorWithX: 0  Y: 0
                                                   Z: thumbnailWidth
                                                   W: thumbnailHeight],
            nil];
    return [crop valueForKey: @"outputImage"];
}

- (void)timerFired: (id)sender
{
    [self setNeedsDisplay: YES];
}

- (void)setSourceImage: (CIImage *)source
{
    [source retain];
    [sourceImage release];
    sourceImage = source;
}

- (void)setTargetImage: (CIImage *)target
{
    [target retain];
    [targetImage release];
    targetImage = target;
}

- (void)setLyricString:(NSString *)aString {
    [aString retain];
    [lyricString release];
    lyricString = aString;
    
    NSData *imageDate = [[textRender render:lyricString] TIFFRepresentation];
    CIImage *image = [[CIImage alloc] initWithData:imageDate];
    [self setSourceImage:image];
    [image release];
    
    [textRender setValue:[NSColor orangeColor] forKey:NSForegroundColorAttributeName];
    imageDate = [[textRender render:lyricString] TIFFRepresentation];
    image = [[CIImage alloc] initWithData:imageDate];
    [self setTargetImage:image];
    
    timer = [[NSTimer alloc] initWithFireDate:[NSDate date] interval:0.05 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
    
    base = 1;
    [[NSRunLoop currentRunLoop] addTimer: timer
                                 forMode: NSDefaultRunLoopMode];
    [[NSRunLoop currentRunLoop] addTimer: timer
                                 forMode: NSEventTrackingRunLoopMode];
    [timer fire];
}

@end
