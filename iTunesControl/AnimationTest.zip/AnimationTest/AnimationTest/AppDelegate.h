//
//  AppDelegate.h
//  AnimationTest
//
//  Created by bo su on 13-7-10.
//  Copyright (c) 2013年 wondershare. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>
#import "VOutTextRender.h"
#import "LyricView.h"

@interface AppDelegate : NSObject <NSApplicationDelegate> {
    IBOutlet LyricView *imageView;
    NSImageView *currentImageView;
    CATextLayer *textLayer;
    
    VOutTextRender *textRender;
    
    NSImage *frogImage;
    NSImage *roseImage;
    CIFilter	*theTransition;
    
    
}

@property (assign) IBOutlet NSWindow *window;

- (IBAction)playText:(id)sender ;

@end
