//
//  main.m
//  AnimationTest
//
//  Created by bo su on 13-7-10.
//  Copyright (c) 2013年 wondershare. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
