//
//  LyricView.h
//  AnimationTest
//
//  Created by bo su on 13-7-11.
//  Copyright (c) 2013年 wondershare. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>
#import "VOutTextRender.h"

@interface LyricView : NSView {
    float thumbnailWidth;
    float thumbnailHeight;
    NSTimeInterval base;
    CIFilter *transition;
    CIContext *context;
    
    CIImage *sourceImage;
    CIImage *targetImage;
    
    NSString *lyricString;
    VOutTextRender *textRender;
    NSTimer *timer;
}

- (void)setLyricString:(NSString *)aString;

@end
